CREATE TRIGGER `StockEmpty`
AFTER UPDATE ON `instock`
FOR EACH ROW
    BEGIN
        IF new.Amount = 0 THEN
            INSERT INTO outofstock (ProductID, OutDate)
                VALUES (new.ProductID, NOW());
        END IF;
    END