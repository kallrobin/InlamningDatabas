CREATE PROCEDURE `TopProducts`(`StartingDate` DATETIME, `EndingDate` DATETIME, `ListAmount` INT(11))
    BEGIN
        SELECT
            products.ProductID,
            products.ProductName,
            SUM(Amount) AS TimesSold
        FROM products
            INNER JOIN productorders ON products.ProductID = productorders.ProductID
            INNER JOIN orderRows ON productorders.OrderID = orderRows.OrderID
        WHERE orderRows.OrderDate BETWEEN StartingDate AND EndingDate
        GROUP BY products.ProductID
        LIMIT ListAmount;
    END