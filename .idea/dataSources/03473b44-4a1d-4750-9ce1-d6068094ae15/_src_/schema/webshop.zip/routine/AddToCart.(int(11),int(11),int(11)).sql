CREATE PROCEDURE `AddToCart`(`CustomerNumber` INT(11), `ProductNumber` INT(11), `OrderNumber` INT(11))
    BEGIN
        IF OrderNumber IS NULL
        THEN
            INSERT INTO OrderRows (CustomerID)
            VALUES (CustomerNumber);
            INSERT INTO productorders (OrderID, ProductID)
            VALUES (LAST_INSERT_ID(), ProductNumber);
        ELSE
            INSERT INTO OrderRows (OrderID, CustomerID)
            VALUES (OrderNumber, CustomerNumber);
            INSERT INTO productorders (OrderID, ProductID)
            VALUES (OrderNumber, ProductNumber);
        END IF;
    END