CREATE VIEW `productspercategory` AS
    SELECT
        `webshop`.`productcategories`.`CategoryName`                                            AS `CategoryName`,
        (SELECT count(`webshop`.`products`.`ProductID`)
         FROM `webshop`.`products`
         WHERE (`webshop`.`products`.`ProductCategoryID` = `webshop`.`productcategories`.`ID`)) AS `Products`
    FROM `webshop`.`productcategories`