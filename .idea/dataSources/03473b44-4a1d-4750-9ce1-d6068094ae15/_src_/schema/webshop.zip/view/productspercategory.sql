CREATE VIEW `productspercategory` AS
    SELECT
        `webshop`.`categories`.`CategoryName`   AS `Category`,
        count(`webshop`.`products`.`ProductID`) AS `Count`
    FROM ((`webshop`.`categories`
        JOIN `webshop`.`productcategories`
            ON ((`webshop`.`categories`.`CategoryID` = `webshop`.`productcategories`.`CategoryID`))) JOIN
        `webshop`.`products` ON ((`webshop`.`productcategories`.`ProductID` = `webshop`.`products`.`ProductID`)))
    GROUP BY `webshop`.`categories`.`CategoryName`
    ORDER BY count(`webshop`.`products`.`ProductID`) DESC