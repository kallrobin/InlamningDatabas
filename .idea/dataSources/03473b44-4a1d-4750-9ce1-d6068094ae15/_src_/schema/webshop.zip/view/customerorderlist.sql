CREATE VIEW `customerorderlist` AS
    SELECT
        concat_ws(' ', `webshop`.`customers`.`FirstName`, `webshop`.`customers`.`LastName`) AS `Customer`,
        (SELECT (sum(`webshop`.`products`.`Price`) * `webshop`.`productorders`.`Amount`))   AS `TotalAmount`
    FROM (((`webshop`.`customers`
        JOIN `webshop`.`orderrows` ON ((`webshop`.`customers`.`CustomerID` = `webshop`.`orderrows`.`CustomerID`))) JOIN
        `webshop`.`productorders` ON ((`webshop`.`orderrows`.`OrderID` = `webshop`.`productorders`.`OrderID`))) JOIN
        `webshop`.`products` ON ((`webshop`.`productorders`.`ProductID` = `webshop`.`products`.`ProductID`)))
    GROUP BY `Customer`
    ORDER BY `TotalAmount` DESC