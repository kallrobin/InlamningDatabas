CREATE VIEW `bestmonth` AS
    SELECT
        (SELECT date_format(`webshop`.`orderrows`.`OrderDate`, '%b %Y'))                  AS `Month`,
        (SELECT (sum(`webshop`.`products`.`Price`) * `webshop`.`productorders`.`Amount`)) AS `TotalAmount`
    FROM ((`webshop`.`orderrows`
        JOIN `webshop`.`productorders`
            ON ((`webshop`.`orderrows`.`OrderID` = `webshop`.`productorders`.`OrderID`))) JOIN `webshop`.`products`
            ON ((`webshop`.`productorders`.`ProductID` = `webshop`.`products`.`ProductID`)))
    GROUP BY `Month`
    ORDER BY `TotalAmount` DESC
    LIMIT 1