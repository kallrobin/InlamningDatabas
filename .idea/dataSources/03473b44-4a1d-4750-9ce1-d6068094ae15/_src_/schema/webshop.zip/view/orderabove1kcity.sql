CREATE VIEW `orderabove1kcity` AS
    SELECT
        `webshop`.`customers`.`City`                                                      AS `City`,
        (SELECT (sum(`webshop`.`products`.`Price`) * `webshop`.`productorders`.`Amount`)) AS `TotalAmount`
    FROM (((`webshop`.`customers`
        JOIN `webshop`.`orderrows` ON ((`webshop`.`customers`.`CustomerID` = `webshop`.`orderrows`.`CustomerID`))) JOIN
        `webshop`.`productorders` ON ((`webshop`.`orderrows`.`OrderID` = `webshop`.`productorders`.`OrderID`))) JOIN
        `webshop`.`products` ON ((`webshop`.`productorders`.`ProductID` = `webshop`.`products`.`ProductID`)))
    GROUP BY `webshop`.`customers`.`City`
    HAVING (`TotalAmount` > 1000)
    ORDER BY `TotalAmount` DESC