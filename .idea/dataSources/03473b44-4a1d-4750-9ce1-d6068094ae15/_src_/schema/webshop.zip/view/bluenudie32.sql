CREATE VIEW `bluenudie32` AS
    SELECT DISTINCT concat_ws(' ', `webshop`.`customers`.`FirstName`, `webshop`.`customers`.`LastName`) AS `Customer`
    FROM (((`webshop`.`customers`
        JOIN `webshop`.`orderrows` ON ((`webshop`.`customers`.`CustomerID` = `webshop`.`orderrows`.`CustomerID`))) JOIN
        `webshop`.`productorders` ON ((`webshop`.`orderrows`.`OrderID` = `webshop`.`productorders`.`OrderID`))) JOIN
        `webshop`.`products` ON ((`webshop`.`productorders`.`ProductID` = `webshop`.`products`.`ProductID`)))
    WHERE ((`webshop`.`products`.`Color` = 'Blue') AND (`webshop`.`products`.`Size` = 32))