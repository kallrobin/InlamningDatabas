CREATE VIEW `top5` AS
    SELECT
        `webshop`.`products`.`ProductID`                 AS `ProductID`,
        `webshop`.`products`.`ProductName`               AS `ProductName`,
        `webshop`.`products`.`Brand`                     AS `Brand`,
        (SELECT sum(`webshop`.`productorders`.`Amount`)
         FROM `webshop`.`productorders`
         WHERE (`webshop`.`products`.`ProductID` = `webshop`.`productorders`.`ProductID`)
         GROUP BY `webshop`.`productorders`.`ProductID`) AS `TimesSold`
    FROM `webshop`.`products`
    ORDER BY `TimesSold` DESC
    LIMIT 5